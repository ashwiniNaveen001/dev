import flet as ft
import pandas as pd
from flet import Page,NavigationBar,NavigationDestination,icons,Text,Icon,colors,NavigationBarLabelBehavior,UserControl 
import datetime
import requests
from requests import ConnectionError
from bs4 import BeautifulSoup
mylist=[]
det=pd.DataFrame()
redet=pd.DataFrame()
reter=pd.DataFrame()
dia='' 
class TASK(ft.Column):
    global det
    global ty
    global i
    def build(self):
        self.slno=ft.TextField(label="Sl.NO:",width=400)
        self.carno=ft.TextField(label="CAR NO.",width=400)
        self.parkby=ft.TextField(label="PARKED BY",width=400)
        self.btn= ft.ElevatedButton(text="Submit",on_click=self.save)
        displayrow=controls=[self.slno,self.carno,self.parkby,self.btn]
        return displayrow
    def save(self,e):
        global det
        global i
        slno=self.slno.value
        carno=self.carno.value
        parkby=self.parkby.value
        carn=carno.upper()
        in_time=datetime.datetime.now()
        in_date=datetime.datetime.now()
        intime=in_time.strftime('%X')
        indate=in_date.strftime('%x')
        b={
        'slno':slno,
        'carno':carn,
        'parkby':parkby,
        'intime':intime,
        'indate':indate,
        }
        det=det.append(b,ignore_index=True)
        det.to_csv('dev gani project.csv')
        self.slno.value=""
        self.carno.value=""
        self.parkby.value=""
        self.update()  
class wig(ft.Column):
    global devli
    global redet
    global det
    def build(self):
        self.h=ft.Column(height=520,
        width=460,
        scroll=ft.ScrollMode.ALWAYS)
        for i in range(len(det)):
            self.sl=ft.Text(det['slno'].iloc[i],size=20,color='red')
            self.cno=ft.Text(det['carno'].iloc[i],size=15)
            self.pno=ft.Text(det['parkby'].iloc[i],size=15)
            sta=STA(self.sl,self.cno,self.pno,self.taskDe)
            self.h.controls.append(sta)
        viwe=controls=[ft.SafeArea(           
                ft.Container(
                    content=ft.Text("AvyuktaSoftwares",
            size=24,
            color=ft.colors.WHITE,
            weight=ft.FontWeight.BOLD,
            italic=True),
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.AMBER,
                    width=460,
                    height=50,
                    border_radius=10,
                )),self.h]
        return viwe
    def taskDe(self,sta):
        global redet
        y=sta.controls
        o=y[0]
        u88=o.controls
        uu3=u88[1]
        u2i=uu3.controls
        n1=u2i[0]
        n2=n1
        n3=n2
        ui=str(n3)
        y1=ui.split()
        y2=y1[2]
        o2=y2.split('}')
        o3=o2[0]
        o4=o3.split("'")
        o5=o4[1]
        t=len(det)
        kol=[]
        for i in range(len(det)):
        	kol.append(i)
        det.index=kol
        u2=[]
        for i in range(len(det)):
            if det['slno'].iloc[i] == o5:
                sirno=det['slno'].iloc[i]
                car_no=det['carno'].iloc[i]
                park_by=det['parkby'].iloc[i]
                devl=sta.devby.value
                out_time=datetime.datetime.now()
                out_date=datetime.datetime.now()
                outtime=out_time.strftime('%X')
                outdate=out_date.strftime('%x')
                intimee=det['intime'].iloc[i]
                indatee=det['indate'].iloc[i]
                b={
                'slno':sirno,
                'carno':car_no,
                'parkby':park_by,
                'devby':devl,
                'intime':intimee,
                'indate':indatee,
                'outtime':outtime,
                'outdate':outdate,
                }
                redet=redet.append(b,ignore_index=True)
                redet.to_csv('returncars ra dev.csv')
                det.drop(i,axis=0,inplace=True)
                det.to_csv('chudham.csv')
                for i in range(len(det)):
                    u2.append(i)
                det.index=u2
                break        
        self.h.controls.remove(sta)
        self.update()
class STA(ft.Column):
		global mylist
		global devli
		global det
		global reter
		global dia
		def __init__(self,sl,car,par,taskde):
			super().__init__()
			self.taskde=taskde
			self.sl=sl
			self.car=car
			self.par=par
		def build(self):
			global devli
			global dia
			global reter
			self.bt2=ft.ElevatedButton(text="Done",on_click=self.dev)
			self.bt=ft.ElevatedButton(text="remove",on_click=self.de)
			self.u=ft.Row(controls=[ft.Text('SL.NO:',size=20),ft.Row(controls=[self.sl])])
			self.g=ft.Row(controls=[ft.Text('VEHICLE NO:',size=20),ft.Row(controls=[self.car])])
			self.io=ft.Row(controls=[ft.Text('PARK BY:',size=20),ft.Row(controls=[self.par])])
			self.b2=ft.Row(controls=[self.bt,self.bt2])
			self.bt3=ft.ElevatedButton(text="done",on_click=self.save)
			self.devby=ft.TextField(label='DeliveryBy',width=300)
			self.edit=ft.Row(visible=False,controls=[self.devby,self.bt3])
			try:				
				g=requests.get('http://192.168.1.185:900')
				soup=BeautifulSoup(g.text,'lxml')
				k=soup.find_all('li')
				for i in range(len(k)):
					h=str(k[i])
					h1=h.split('<li>')
					h2=str(h1[1])
					h3=h2.split("</li>")
					h4=str(h3[0])
					mylist.append(h4)
				u58=[]
				for i in range(len(det)):
					u58.append(i)
				det.index=u58
				u=[]
				for n in range(len(det)):
					for q in range(len(mylist)):
						if det['slno'].iloc[n]==mylist[q]:
							b={
                			'slno': det['slno'].iloc[n],
                			'carno': det['carno'].iloc[n],
                			'parkby': det['parkby'].iloc[n],
                			'intime': det['intime'].iloc[n],
                			'indate': det['indate'].iloc[n],
                			}
							reter=reter.append(b,ignore_index=True)
							h=det['slno'].iloc[n]
							h1=det['carno'].iloc[n]
							det.drop(n,axis=0,inplace=True)
							for o in range(len(det)):
								u.append(i)
							det.index=u
							dia=ft.AlertDialog(modal=True,title=ft.Text('Alert for delivery'),content=ft.Text(f'sl no:{h},car no:{h1} whats his/her car'),
        		actions=[ft.TextButton("ok",on_click=self.close_dialog)],actions_alignment=ft.MainAxisAlignment.END,on_dismiss=lambda e:print('modal dialog dismiss'))
							self.dialog=dia
							dia.open=True
							devli=True
							print(reter)	
							break
			except ConnectionError:
				print('connection problem ra')
			if devli==True:
				view1=controls=[self.u,self.g,self.io,self.b2,self.edit,dia]
				devli=False
			else:
				view1=controls=[self.u,self.g,self.io,self.b2,self.edit]
			return view1
		def dev(self,e):
			self.b2.visible=False
			self.edit.visible=True
			self.update()
		def save(self,e):
			devli=self.devby.value
			self.taskde(self)
		def de(self,e):
			self.taskde(self)
		def close_dialog(self,e):
			global dia
			dia.open=False
			self.update()
class RETURNC(ft.Column):
    global reter
    global redet
    def build(self):
        self.h=ft.Column(height=520,
        width=460,
        scroll=ft.ScrollMode.ALWAYS)
        for i in range(len(reter)):
            self.sl=ft.Text(reter['slno'].iloc[i],size=30,color='red')
            self.cno=ft.Text(reter['carno'].iloc[i],size=20)
            self.pno=ft.Text(reter['parkby'].iloc[i],size=20)
            self.intime=ft.Text(reter['intime'].iloc[i],size=15)
            self.indate=ft.Text(reter['indate'].iloc[i],size=15)
            self.slv=ft.Row(controls=[ft.Text('Slno',size=20),self.sl])
            self.card=ft.Row(controls=[ft.Text('CAR NO:',size=15),self.cno],alignment=ft.MainAxisAlignment.SPACE_AROUND)
            self.pard=ft.Row(controls=[ft.Text('PARKED BY:',size=15),self.pno,ft.Text('IN TIME:',size=10),self.intime,self.indate],alignment=ft.MainAxisAlignment.SPACE_AROUND)
            vie=ft.Column(controls=[self.slv,self.card,self.pard])
            self.h.controls.append(vie)
        viwe=controls=[ft.SafeArea(        
                ft.Container(
                    content=ft.Text("AvyuktaSoftwares",
            size=24,
            color=ft.colors.WHITE,
            weight=ft.FontWeight.BOLD,
            italic=True),
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.AMBER,
                    width=460,
                    height=50,
                    border_radius=10,
                )),self.h]
        return viwe
i=0
r=0
devli='uu'
n=False
def main(page: ft.Page):
    global n
    global det
    global i,r
    global reter
    global redet
    page.title = "NavigationBar Example"
    page.bgcolor='E8B86D'
    page.navigation_bar = ft.NavigationBar(
        destinations=[
            ft.NavigationBarDestination(icon=ft.icons.KEY, label="Explore"),
            ft.NavigationBarDestination(icon=ft.icons.COMMUTE, label="Commute"),
            ft.NavigationBarDestination(
                icon=ft.icons.BOOKMARK_BORDER,
                selected_icon=ft.icons.BOOKMARK,
                label="Exploree",
            ),
        ],
        on_change=lambda e:set_page(e)
    )
    task=TASK()
    uu=wig()
    retun=RETURNC()
    def set_page(e):
        global r,i
        page.clean()
        page_index=e.control.selected_index
        page_label=e.control.destinations[page_index].label
        if page_label=='Exploree':
            page.add(ft.SafeArea(     
                ft.Container(
                    content=ft.Text("AvyuktaSoftwares",
            size=24,
            color=ft.colors.WHITE,
            weight=ft.FontWeight.BOLD,
            italic=True),
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.AMBER,
                    width=460,
                    height=50,
                    border_radius=10,
                )),task)               
        if page_label=='Explore':
           global redet
           global reter
           if len(reter)>0:
                page.add(retun)
           if len(reter)<=0:
                 page.add(ft.SafeArea(
                ft.Container(
                    content=ft.Text("AvyuktaSoftwares",
            size=24,
            color=ft.colors.WHITE,
            weight=ft.FontWeight.BOLD,
            italic=True),
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.AMBER,
                    width=460,
                    height=50,
                    border_radius=10,
                )),ft.Text('no data',size=40))
        if page_label=='Commute':
            if len(det)>0:
                page.add(uu)
            if len(det)==0:
                t=Text('no data')
                page.add(ft.SafeArea(
                ft.Container(
                    content=ft.Text("AvyuktaSoftwares",
            size=24,
            color=ft.colors.WHITE,
            weight=ft.FontWeight.BOLD,
            italic=True),
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.AMBER,
                    width=460,
                    height=50,
                    border_radius=10,
                )),t)
    page.add(ft.SafeArea(
                ft.Container(
                    content=ft.Text("AvyuktaSoftwares",
            size=24,
            color=ft.colors.WHITE,
            weight=ft.FontWeight.BOLD,
            italic=True),
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.AMBER,
                    width=460,
                    height=50,
                    border_radius=10,
                )),ft.Text("Bodyyy!"))

ft.app(target=main,view=ft.AppView.WEB_BROWSER)





